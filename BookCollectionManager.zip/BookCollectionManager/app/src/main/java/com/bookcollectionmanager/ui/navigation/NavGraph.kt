package com.bookcollectionmanager.ui.navigation

import androidx.compose.runtime.*
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.bookcollectionmanager.data.repository.BookRepository
import com.bookcollectionmanager.data.datastore.PreferenceManager
import com.bookcollectionmanager.ui.screens.main.MainScreen
import com.bookcollectionmanager.ui.screens.main.MainViewModel
import com.bookcollectionmanager.ui.screens.add_edit.AddEditScreen
import com.bookcollectionmanager.ui.screens.add_edit.AddEditViewModel
import com.bookcollectionmanager.ui.screens.settings.SettingsScreen
import com.bookcollectionmanager.ui.screens.settings.SettingsViewModel

@Composable
fun NavGraph(
    mainViewModel: MainViewModel,
    repository: BookRepository,
    preferenceManager: PreferenceManager
) {

    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "main"
    ) {

        // ---------------- MAIN SCREEN ----------------
        composable("main") {
            MainScreen(
                viewModel = mainViewModel,
                onAddClick = {
                    navController.navigate("add_edit")
                },
                onEditClick = { bookId ->
                    navController.navigate("add_edit?bookId=$bookId")
                },
                onSettingsClick = {
                    navController.navigate("settings")
                }
            )
        }

        // ---------------- ADD / EDIT SCREEN ----------------
        composable(
            route = "add_edit?bookId={bookId}",
            arguments = listOf(
                navArgument("bookId") {
                    type = NavType.IntType
                    defaultValue = -1
                }
            )
        ) { backStackEntry ->

            val bookId = backStackEntry.arguments?.getInt("bookId") ?: -1

            val addEditViewModel = remember {
                AddEditViewModel(repository)
            }

            LaunchedEffect(bookId) {
                if (bookId != -1) {
                    val book = repository.getBookById(bookId)
                    book?.let {
                        addEditViewModel.loadBook(it)
                    }
                }
            }

            AddEditScreen(
                viewModel = addEditViewModel,
                onSave = {
                    navController.popBackStack()
                }
            )
        }

        // ---------------- SETTINGS SCREEN ----------------
        composable("settings") {

            val settingsViewModel = remember {
                SettingsViewModel(preferenceManager)
            }

            SettingsScreen(
                viewModel = settingsViewModel,
                onBackClick = {
                    navController.popBackStack()
                }
            )
        }
    }
}