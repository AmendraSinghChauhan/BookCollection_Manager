package com.bookcollectionmanager.ui.screens.settings


import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.bookcollectionmanager.data.datastore.PreferenceManager
import com.bookcollectionmanager.utils.SortType
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val preferenceManager: PreferenceManager
) : ViewModel() {

    val sortType: StateFlow<SortType> =
        preferenceManager.sortFlow
            .stateIn(
                viewModelScope,
                SharingStarted.WhileSubscribed(5000),
                SortType.DATE
            )

    fun changeSort(sortType: SortType) {
        viewModelScope.launch {
            preferenceManager.saveSortType(sortType)
        }
    }
}