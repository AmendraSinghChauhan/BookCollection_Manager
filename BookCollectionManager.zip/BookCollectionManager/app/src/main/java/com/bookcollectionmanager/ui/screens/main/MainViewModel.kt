package com.bookcollectionmanager.ui.screens.main

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.bookcollectionmanager.data.local.Book
import com.bookcollectionmanager.data.repository.BookRepository
import com.bookcollectionmanager.data.datastore.PreferenceManager
import com.bookcollectionmanager.utils.SortType
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(
    private val repository: BookRepository,
    private val preferenceManager: PreferenceManager
) : ViewModel() {

    // ----------------------------
    // Sort State
    // ----------------------------
    private val _sortType = MutableStateFlow(SortType.DATE)
    val sortType: StateFlow<SortType> = _sortType.asStateFlow()

    // ----------------------------
    // Search State
    // ----------------------------
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // ----------------------------
    // Combined Books Flow
    // ----------------------------
    val books: StateFlow<List<Book>> =
        combine(_sortType, _searchQuery) { sort, query ->
            sort to query
        }.flatMapLatest { (sort, query) ->
            if (query.isBlank()) {
                repository.getBooks(sort)
            } else {
                repository.searchBooks(query)
            }
        }.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

    // ----------------------------
    // Init - Load Saved Sort
    // ----------------------------
    init {
        viewModelScope.launch {
            preferenceManager.sortFlow.collect { savedSort ->
                _sortType.value = savedSort
            }
        }
    }

    // ----------------------------
    // Actions
    // ----------------------------

    fun changeSort(sortType: SortType) {
        viewModelScope.launch {
            preferenceManager.saveSortType(sortType)
        }
    }

    fun onSearchChange(query: String) {
        _searchQuery.value = query
    }

    fun deleteBook(book: Book) {
        viewModelScope.launch {
            repository.delete(book)
        }
    }

    fun toggleFavorite(book: Book) {
        viewModelScope.launch {
            repository.updateFavorite(book.id, !book.isFavorite)
        }
    }

}