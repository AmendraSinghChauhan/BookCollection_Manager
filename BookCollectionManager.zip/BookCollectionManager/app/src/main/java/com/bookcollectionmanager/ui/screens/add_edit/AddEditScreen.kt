package com.bookcollectionmanager.ui.screens.add_edit

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun AddEditScreen(
    viewModel: AddEditViewModel,
    onSave: () -> Unit
) {

    val title by viewModel.title.collectAsState()
    val author by viewModel.author.collectAsState()
    val genre by viewModel.genre.collectAsState()
    val rating by viewModel.rating.collectAsState()

    Column(Modifier.padding(16.dp)) {

        OutlinedTextField(
            value = title,
            onValueChange = { viewModel.onTitleChange(it) },
            label = { Text("Title") }
        )

        OutlinedTextField(
            value = author,
            onValueChange = { viewModel.onAuthorChange(it) },
            label = { Text("Author") }
        )

        OutlinedTextField(
            value = genre,
            onValueChange = { viewModel.onGenreChange(it) },
            label = { Text("Genre") }
        )

        OutlinedTextField(
            value = rating.toString(),
            onValueChange = {
                viewModel.onRatingChange(it.toIntOrNull() ?: 1)
            },
            label = { Text("Rating (1-5)") }
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                viewModel.saveBook()
                onSave()
            }
        ) {
            Text("Save")
        }
    }
}