package com.bookcollectionmanager.ui.screens.add_edit


import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.bookcollectionmanager.data.local.Book
import com.bookcollectionmanager.data.repository.BookRepository

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class AddEditViewModel(
    private val repository: BookRepository
) : ViewModel() {

    // UI State
    private val _title = MutableStateFlow("")
    val title: StateFlow<String> = _title

    private val _author = MutableStateFlow("")
    val author: StateFlow<String> = _author

    private val _genre = MutableStateFlow("")
    val genre: StateFlow<String> = _genre

    private val _rating = MutableStateFlow(1)
    val rating: StateFlow<Int> = _rating

    private var currentBookId: Int? = null

    // -------------------------
    // Update Functions
    // -------------------------

    fun onTitleChange(value: String) {
        _title.value = value
    }

    fun onAuthorChange(value: String) {
        _author.value = value
    }

    fun onGenreChange(value: String) {
        _genre.value = value
    }

    fun onRatingChange(value: Int) {
        _rating.value = value
    }

    // -------------------------
    // Insert or Update
    // -------------------------

    fun saveBook() {
        if (_title.value.isBlank() || _author.value.isBlank()) return
        if (_rating.value !in 1..5) return

        viewModelScope.launch {
            val book = Book(
                id = currentBookId ?: 0,
                title = _title.value,
                author = _author.value,
                genre = _genre.value,
                rating = _rating.value
            )

            if (currentBookId == null) {
                repository.insert(book)
            } else {
                repository.update(book)
            }
        }
    }

    // -------------------------
    // Load Book for Edit
    // -------------------------

    fun loadBook(book: Book) {
        currentBookId = book.id
        _title.value = book.title
        _author.value = book.author
        _genre.value = book.genre ?: ""
        _rating.value = book.rating
    }
}