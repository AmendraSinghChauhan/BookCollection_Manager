package com.bookcollectionmanager.data.datastore


import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.bookcollectionmanager.utils.SortType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "settings")

class PreferenceManager(private val context: Context) {

    companion object {
        val SORT_KEY = stringPreferencesKey("sort_key")
    }

    val sortFlow: Flow<SortType> = context.dataStore.data.map { preferences ->
        SortType.valueOf(
            preferences[SORT_KEY] ?: SortType.DATE.name
        )
    }

    suspend fun saveSortType(sortType: SortType) {
        context.dataStore.edit { preferences ->
            preferences[SORT_KEY] = sortType.name
        }
    }
}