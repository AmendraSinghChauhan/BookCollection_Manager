package com.bookcollectionmanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.bookcollectionmanager.data.local.BookDatabase
import com.bookcollectionmanager.data.repository.BookRepository
import com.bookcollectionmanager.data.datastore.PreferenceManager
import com.bookcollectionmanager.ui.navigation.NavGraph
import com.bookcollectionmanager.ui.screens.main.MainViewModel
import com.bookcollectionmanager.ui.screens.main.MainViewModelFactory

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val dao = BookDatabase.getInstance(this).bookDao()
        val repository = BookRepository(dao)
        val preferenceManager = PreferenceManager(this)

        setContent {

            val factory = MainViewModelFactory(repository, preferenceManager)

            val mainViewModel: MainViewModel = viewModel(
                factory = factory
            )

            NavGraph(
                mainViewModel = mainViewModel,
                repository = repository,
                preferenceManager = preferenceManager
            )
        }
    }
}

//@Composable
//fun Greeting(name: String, modifier: Modifier = Modifier) {
//    Text(
//        text = "Hello $name!",
//        modifier = modifier
//    )
//}
//
//@Preview(showBackground = true)
//@Composable
//fun GreetingPreview() {
//    BookCollectionManagerTheme {
//        Greeting("Android")
//    }
//}