package com.bookcollectionmanager.ui.screens.main


import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.bookcollectionmanager.utils.SortType

@Composable
fun SortMenu(
    selectedSort: SortType,
    onSortSelected: (SortType) -> Unit
) {

    var expanded by remember { mutableStateOf(false) }

    Box(modifier = Modifier.padding(8.dp)) {

        Button(onClick = { expanded = true }) {
            Text(text = "Sort: ${selectedSort.name}")
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {

            SortType.values().forEach { type ->
                DropdownMenuItem(
                    text = { Text(type.name) },
                    onClick = {
                        onSortSelected(type)
                        expanded = false
                    }
                )
            }
        }
    }
}