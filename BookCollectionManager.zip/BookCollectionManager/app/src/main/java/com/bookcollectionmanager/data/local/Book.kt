package com.bookcollectionmanager.data.local


import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "books")
data class Book(

    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,

    val title: String,
    val author: String,
    val genre: String?,
    val rating: Int,

    val dateAdded: Long = System.currentTimeMillis(),

    val isFavorite: Boolean = false
)