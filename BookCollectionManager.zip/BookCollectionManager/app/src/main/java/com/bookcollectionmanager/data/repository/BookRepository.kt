package com.bookcollectionmanager.data.repository



import  com.bookcollectionmanager.data.local.Book
import  com.bookcollectionmanager.data.local.BookDao

import com.bookcollectionmanager.utils.SortType
import kotlinx.coroutines.flow.Flow

class BookRepository(private val dao: BookDao) {

    fun getBooks(sortType: SortType): Flow<List<Book>> {
        return when (sortType) {
            SortType.DATE -> dao.getBooksByDate()
            SortType.TITLE -> dao.getBooksByTitle()
            SortType.AUTHOR -> dao.getBooksByAuthor()
            SortType.RATING -> dao.getBooksByRating()
        }
    }

    suspend fun insert(book: Book) = dao.insert(book)

    suspend fun update(book: Book) = dao.update(book)

    suspend fun getBookById(id: Int): Book? {
        return dao.getBookById(id)
    }

    fun searchBooks(query: String): Flow<List<Book>> {
        return dao.searchBooks(query)
    }
    suspend fun delete(book: Book) = dao.delete(book)
    suspend fun updateFavorite(id: Int, isFavorite: Boolean) {
        dao.updateFavorite(id, isFavorite)
    }
}