package com.bookcollectionmanager.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.bookcollectionmanager.data.local.Book

@Composable
fun BookItem(
    book: Book,
    onDelete: () -> Unit,
    onEdit: () -> Unit,
    onFavoriteToggle: () -> Unit
) {

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {

        Column(
            modifier = Modifier.padding(12.dp)
        ) {

            // Title
            Text(
                text = book.title,
                style = MaterialTheme.typography.titleMedium
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Author
            Text(text = "Author: ${book.author}")

            // Genre (optional)
            book.genre?.let {
                Text(text = "Genre: $it")
            }

            // Rating
            Text(text = "Rating: ${book.rating} ⭐")

            Spacer(modifier = Modifier.height(8.dp))

            // Action Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {

                Row {
                    Button(onClick = onEdit) {
                        Text("Edit")
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(onClick = onDelete) {
                        Text("Delete")
                    }
                }

                // Favorite Checkbox
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Favorite")
                    Spacer(modifier = Modifier.width(4.dp))
                    Checkbox(
                        checked = book.isFavorite,
                        onCheckedChange = { onFavoriteToggle() }
                    )
                }
            }
        }
    }
}