package com.bookcollectionmanager.data.local


import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface BookDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(book: Book)

    @Update
    suspend fun update(book: Book)

    @Delete
    suspend fun delete(book: Book)

    @Query("SELECT * FROM books ORDER BY dateAdded DESC")
    fun getBooksByDate(): Flow<List<Book>>

    @Query("SELECT * FROM books ORDER BY title ASC")
    fun getBooksByTitle(): Flow<List<Book>>

    @Query("SELECT * FROM books ORDER BY author ASC")
    fun getBooksByAuthor(): Flow<List<Book>>

    @Query("SELECT * FROM books ORDER BY rating DESC")
    fun getBooksByRating(): Flow<List<Book>>

    @Query("SELECT * FROM books WHERE id = :id")
    suspend fun getBookById(id: Int): Book?

    @Query("SELECT * FROM books WHERE title LIKE '%' || :query || '%'")
    fun searchBooks(query: String): Flow<List<Book>>

    @Query("UPDATE books SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun updateFavorite(id: Int, isFavorite: Boolean)
}