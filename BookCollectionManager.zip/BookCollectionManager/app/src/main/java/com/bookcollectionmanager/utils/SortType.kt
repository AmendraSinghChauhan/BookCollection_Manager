package com.bookcollectionmanager.utils

enum class SortType {
    DATE,
    TITLE,
    AUTHOR,
    RATING
}