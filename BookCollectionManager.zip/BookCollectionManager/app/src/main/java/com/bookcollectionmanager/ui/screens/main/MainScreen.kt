package com.bookcollectionmanager.ui.screens.main

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.bookcollectionmanager.ui.components.BookItem

@Composable
fun MainScreen(
    viewModel: MainViewModel,
    onAddClick: () -> Unit,
    onEditClick: (Int) -> Unit,   // 👈 navigation yaha se handle hoga
    onSettingsClick: () -> Unit
) {

    val books by viewModel.books.collectAsState()
    val sortType by viewModel.sortType.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = onAddClick) {
                Text("+")
            }
        }
    ) { padding ->

        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {

            // 🔍 Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.onSearchChange(it) },
                label = { Text("Search by Title") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
            )

            // 🔽 Sort Menu
            SortMenu(sortType) {
                viewModel.changeSort(it)
            }

            // 📚 Book List
            if (books.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = androidx.compose.ui.Alignment.Center
                ) {
                    Text("No Books Added Yet")
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(books) { book ->
                        BookItem(
                            book = book,
                            onDelete = { viewModel.deleteBook(book) },
                            onEdit = { onEditClick(book.id) },
                            onFavoriteToggle = {
                                viewModel.toggleFavorite(book)
                            }
                        )
                    }
                }
            }
        }
    }
}